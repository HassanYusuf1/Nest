
using InstagramMVC.Models;
using Microsoft.EntityFrameworkCore;
 
namespace InstagramMVC.DAL
{
    public class KommentarRepository : IKommentarRepository
    {
        private readonly MediaDbContext _context;

        private readonly ILogger<KommentarRepository> _logger;

        public KommentarRepository( MediaDbContext context, ILogger<KommentarRepository> logger )
        {
            _context = context;
            _logger = logger;
        }

        public async Task<IEnumerable<Kommentar>> GetAll()
        {
            try
            {
                return await _context.Kommentarer.ToListAsync();

            }
            catch(Exception e)
            {
                _logger.LogError(e, "[KommentarRepository] Kommentar ToListAsync Feilet, Når GetAll() ble brukt. Feilmelding: {ErrorMessage}", e.Message);
                 return Enumerable.Empty<Kommentar>();
            }
        }


        public async Task<Kommentar?> GetKommentarById(int id)
        {
            try
            {
                return await _context.Kommentarer.FindAsync(id);

            }
            catch(Exception e)
            {
                _logger.LogError(e, "[KommentarRepository] Feilet når man bruker GetKommentarById for KommentarId {KommentarId:0000}. Feilmelding: {ErrorMessage}", id, e.Message);
                return null;

            }
        }

        public async Task<int?> GetBildeId(int id)
        {
            var kommentar = await _context.Kommentarer.FindAsync(id);
            if (kommentar == null)
            {
                _logger.LogWarning("Kommentar med ID {KommentarId} ble ikke funnet når man prøvde å hente BildeId", id);
                return null;
            }
            return kommentar.BildeId;
        }
        public async Task<int?> GetNoteId(int id)
        {
            var kommentar = await _context.Kommentarer.FindAsync(id);
            if (kommentar == null)
            {
                _logger.LogWarning("Kommentar med ID {KommentarId} ble ikke funnet når man prøvde å hente NoteId", id);
                return null;
            }
            return kommentar.NoteId;
        }

        public async Task Create(Kommentar kommentar)
        {
            try
            {
                _context.Kommentarer.Add(kommentar);
                await _context.SaveChangesAsync();

            }
            catch(Exception e)
            {
                _logger.LogError(e, "[KommentarRepository] Feil ved opprettelse av kommentar med id {@Kommentar}. Feilmelding: {ErrorMessage}", kommentar, e.Message);
            }
        }

        public async Task Update(Kommentar kommentar)
        {
            _context.Kommentarer.Update(kommentar);
            await _context.SaveChangesAsync();

        }

        public async Task<bool> Delete(int id)
        {
            try
            {
                var kommentar = await _context.Kommentarer.FindAsync(id);

                if(kommentar == null)
                {
                    return false;
                }
                _context.Kommentarer.Remove(kommentar);
                await _context.SaveChangesAsync();
                return true;
            }

            
            catch(Exception e)
            {
                _logger.LogError(e, "[KommentarRepository] feilet ved sletting av kommentar med ID {KommentarId:0000}. Feilmelding: {ErrorMessage}", id, e.Message);
                return false;
            }
                
        }

    }
}