using InstagramMVC.Models;

namespace InstagramMVC.ViewModels
{
    public class NoteKommentarViewModel
    {
        public Note? Note { get; set; } 
        public KommentarViewModel? KommentarViewModel { get; set; }  
    }
}
