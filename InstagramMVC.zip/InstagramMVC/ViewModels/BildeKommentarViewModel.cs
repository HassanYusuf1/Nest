using InstagramMVC.Models;

namespace InstagramMVC.ViewModels
{
    public class BildeKommentarViewModel
    {
        public Bilde? Bilde { get; set; } 
        public KommentarViewModel? KommentarViewModel { get; set; }  
    }
}
