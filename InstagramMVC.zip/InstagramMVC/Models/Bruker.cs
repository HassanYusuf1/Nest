namespace InstagramMVC.Models{
public class Bruker {
    public int Id { get; set;}
    public  string? BrukerNavn {get; set;}
    public string? Epost {get; set;}
    public String? Passord {get; set;}


   
     


}


}   